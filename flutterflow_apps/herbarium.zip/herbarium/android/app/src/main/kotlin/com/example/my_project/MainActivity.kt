package com.mkajdan.herbarium

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
