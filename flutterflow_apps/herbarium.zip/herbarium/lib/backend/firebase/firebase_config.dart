import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyDibU4HoJ2sgnb5dp4HeJGC3y8lVqRTkrA",
            authDomain: "flowers-8232f.firebaseapp.com",
            projectId: "flowers-8232f",
            storageBucket: "flowers-8232f.appspot.com",
            messagingSenderId: "274270122217",
            appId: "1:274270122217:web:05de968b7a9550e8e7c078"));
  } else {
    await Firebase.initializeApp();
  }
}
