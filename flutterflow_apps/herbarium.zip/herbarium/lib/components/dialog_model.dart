import '/flutter_flow/flutter_flow_util.dart';
import 'dialog_widget.dart' show DialogWidget;
import 'package:flutter/material.dart';

class DialogModel extends FlutterFlowModel<DialogWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
