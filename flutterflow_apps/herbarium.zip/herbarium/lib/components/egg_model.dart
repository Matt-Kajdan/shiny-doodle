import '/flutter_flow/flutter_flow_util.dart';
import 'egg_widget.dart' show EggWidget;
import 'package:flutter/material.dart';

class EggModel extends FlutterFlowModel<EggWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
